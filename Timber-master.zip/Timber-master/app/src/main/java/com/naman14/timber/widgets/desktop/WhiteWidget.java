package com.naman14.timber.widgets.desktop;

import com.naman14.timber.R;

/**
 * Created by nv95 on 11.11.16.
 */

public class WhiteWidget extends StandardWidget {

    @Override
    int getLayoutRes() {
        return R.layout.widget_white;
    }
}
